export interface Project {
  id: string;
  user_id: string;
  name: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export interface Output {
  id: string;
  project_id: string;
  user_id: string;
  output_data: Record<string, any>;
  output_type: string;
  created_at: string;
}

export interface UserCredits {
  id: string;
  user_id: string;
  credits_remaining: number;
  total_credits_used: number;
  created_at: string;
  updated_at: string;
}

export interface CreditTransaction {
  id: string;
  user_id: string;
  credits_change: number;
  transaction_type: 'initial' | 'usage' | 'purchase' | 'refund';
  output_id: string | null;
  success: boolean;
  created_at: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  credits: number;
  price: number;
  active: boolean;
  created_at: string;
}
