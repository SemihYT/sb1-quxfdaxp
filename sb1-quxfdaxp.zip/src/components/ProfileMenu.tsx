import { useState, useEffect, useRef } from 'react';
import { User, Settings, CreditCard, LogOut, TrendingUp, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { UserCredits, SubscriptionPlan } from '../types/database';

interface ProfileMenuProps {
  onLogout: () => void;
  onUpgrade: () => void;
}

export default function ProfileMenu({ onLogout, onUpgrade }: ProfileMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [userEmail, setUserEmail] = useState<string>('');
  const [credits, setCredits] = useState<UserCredits | null>(null);
  const [hasActivePlan, setHasActivePlan] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchUserData();

    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchUserData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      setUserEmail(user.email || '');

      const { data: creditsData } = await supabase
        .from('user_credits')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (creditsData) {
        setCredits(creditsData);
        setHasActivePlan(creditsData.total_credits_used > 3);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 bg-white dark:bg-gray-800 border-2 border-purple-600 dark:border-purple-500 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-gray-700 rounded-lg transition duration-200"
      >
        <User className="w-4 h-4 sm:w-5 sm:h-5" />
        <span className="hidden sm:inline font-semibold">Profile</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-purple-100 dark:border-gray-700 z-50 transition-colors duration-200">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">{userEmail}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {hasActivePlan ? 'Premium User' : 'Free User'}
                </p>
              </div>
            </div>
          </div>

          <div className="p-2">
            <div className="px-3 py-2 mb-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Credits</span>
                <span className="text-sm font-bold text-purple-600 dark:text-purple-400">
                  {credits?.credits_remaining || 0}
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-purple-600 dark:bg-purple-500 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.min(((credits?.credits_remaining || 0) / 10) * 100, 100)}%`,
                  }}
                />
              </div>
            </div>

            {hasActivePlan ? (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onUpgrade();
                }}
                className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-purple-50 dark:hover:bg-gray-700 rounded-lg transition text-sm"
              >
                <TrendingUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span className="text-gray-700 dark:text-gray-200">Manage Subscription</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onUpgrade();
                }}
                className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-purple-50 dark:hover:bg-gray-700 rounded-lg transition text-sm"
              >
                <TrendingUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span className="text-gray-700 dark:text-gray-200">Upgrade Plan</span>
              </button>
            )}

            <button
              onClick={() => {
                setIsOpen(false);
                onLogout();
              }}
              className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition text-sm text-red-600 dark:text-red-400"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
