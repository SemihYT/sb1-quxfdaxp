import React, { useState } from 'react'
import { Button } from '../ui/Button'
import { createCheckoutSession } from '../../services/stripe'
import { StripeProduct } from '../../stripe-config'

interface PricingCardProps {
  product: StripeProduct
  isPopular?: boolean
}

export function PricingCard({ product, isPopular = false }: PricingCardProps) {
  const [loading, setLoading] = useState(false)

  const handleSubscribe = async () => {
    try {
      setLoading(true)
      const checkoutUrl = await createCheckoutSession({
        priceId: product.priceId,
        mode: product.mode
      })
      
      window.location.href = checkoutUrl
    } catch (error) {
      console.error('Error creating checkout session:', error)
      // You could show an error message here
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`relative rounded-2xl border ${
      isPopular 
        ? 'border-blue-500 shadow-lg scale-105' 
        : 'border-gray-200 shadow-sm'
    } bg-white p-8`}>
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-medium">
            Most Popular
          </span>
        </div>
      )}
      
      <div className="text-center">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">
          {product.name}
        </h3>
        
        <div className="mb-4">
          <span className="text-4xl font-bold text-gray-900">
            ${product.price}
          </span>
          <span className="text-gray-500 ml-1">
            /{product.mode === 'subscription' ? 'month' : 'one-time'}
          </span>
        </div>
        
        <p className="text-gray-600 mb-6">
          {product.description}
        </p>
        
        <Button
          onClick={handleSubscribe}
          loading={loading}
          variant={isPopular ? 'primary' : 'outline'}
          className="w-full"
        >
          {product.mode === 'subscription' ? 'Subscribe' : 'Purchase'}
        </Button>
      </div>
    </div>
  )
}