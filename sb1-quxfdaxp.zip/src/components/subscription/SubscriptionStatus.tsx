import React from 'react'
import { useSubscription } from '../../hooks/useSubscription'
import { Alert } from '../ui/Alert'

export function SubscriptionStatus() {
  const { subscription, loading, error, plan, isActive } = useSubscription()

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
      </div>
    )
  }

  if (error) {
    return (
      <Alert type="error">
        Failed to load subscription status
      </Alert>
    )
  }

  if (!subscription || !plan) {
    return (
      <div className="text-sm text-gray-600">
        No active subscription
      </div>
    )
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center space-x-2">
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          isActive 
            ? 'bg-green-100 text-green-800' 
            : 'bg-yellow-100 text-yellow-800'
        }`}>
          {subscription.subscription_status}
        </span>
        <span className="text-sm font-medium text-gray-900">
          {plan.name} Plan
        </span>
      </div>
      
      {subscription.current_period_end && (
        <div className="text-xs text-gray-500">
          {subscription.cancel_at_period_end ? 'Cancels' : 'Renews'} on{' '}
          {new Date(subscription.current_period_end * 1000).toLocaleDateString()}
        </div>
      )}
    </div>
  )
}