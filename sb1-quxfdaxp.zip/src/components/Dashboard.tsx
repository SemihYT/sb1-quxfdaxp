import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Folder, Trash2, Clock, Sparkles, CreditCard, TrendingUp, Download, Loader2 } from 'lucide-react';
import FaceSwap from './FaceSwap';
import SubscriptionPlans from './SubscriptionPlans';
import ProfileMenu from './ProfileMenu';
import ThemeToggle from './ThemeToggle';
import type { Project, Output, UserCredits } from '../types/database';

export default function Dashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [outputs, setOutputs] = useState<Output[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewProject, setShowNewProject] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');
  const [showFaceSwap, setShowFaceSwap] = useState(false);
  const [showSubscriptions, setShowSubscriptions] = useState(false);
  const [credits, setCredits] = useState<UserCredits | null>(null);
  const [hasActivePlan, setHasActivePlan] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState<Record<string, boolean>>({});
  const pollingIntervals = useRef<Record<string, NodeJS.Timeout>>({});

  useEffect(() => {
    fetchProjects();
    fetchCredits();
  }, []);

  useEffect(() => {
    if (selectedProject) {
      fetchOutputs(selectedProject.id);
    }
    return () => {
      Object.values(pollingIntervals.current).forEach(clearInterval);
    };
  }, [selectedProject]);

  const fetchCredits = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_credits')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;
      setCredits(data);
      if (data) {
        setHasActivePlan(data.total_credits_used > 3);
      }
    } catch (error) {
      console.error('Error fetching credits:', error);
    }
  };

  const fetchProjects = async () => {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchOutputs = async (projectId: string) => {
    try {
      const { data, error } = await supabase
        .from('outputs')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOutputs(data || []);

      data?.forEach((output) => {
        const status = output.output_data.status;
        const hasOutput = output.output_data.output;
        if (!hasOutput && status !== 'succeeded' && status !== 'failed' && status !== 'canceled' && !pollingIntervals.current[output.id]) {
          console.log(`Starting polling for output ${output.id} with status: ${status}`);
          startPolling(output.id);
        }
      });
    } catch (error) {
      console.error('Error fetching outputs:', error);
    }
  };

  const startPolling = (outputId: string) => {
    pollingIntervals.current[outputId] = setInterval(async () => {
      await checkOutputStatus(outputId);
    }, 5000);
  };

  const checkOutputStatus = async (outputId: string) => {
    setCheckingStatus(prev => ({ ...prev, [outputId]: true }));
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/check-face-swap-status`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ outputId }),
        }
      );

      if (!response.ok) {
        console.error('Status check failed:', response.status);
        return;
      }

      const result = await response.json();
      console.log('Status check result:', result);

      if (result.status === 'succeeded' || result.status === 'failed' || result.status === 'canceled') {
        console.log(`Output ${outputId} finished with status: ${result.status}`);
        if (pollingIntervals.current[outputId]) {
          clearInterval(pollingIntervals.current[outputId]);
          delete pollingIntervals.current[outputId];
        }
        if (selectedProject) {
          await fetchOutputs(selectedProject.id);
        }
      } else {
        console.log(`Output ${outputId} still processing: ${result.status}`);
      }
    } catch (error) {
      console.error('Error checking status:', error);
    } finally {
      setCheckingStatus(prev => ({ ...prev, [outputId]: false }));
    }
  };

  const createProject = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('projects')
        .insert([
          {
            user_id: user.id,
            name: newProjectName,
            description: newProjectDescription,
          },
        ])
        .select()
        .single();

      if (error) throw error;
      setProjects([data, ...projects]);
      setNewProjectName('');
      setNewProjectDescription('');
      setShowNewProject(false);
    } catch (error) {
      console.error('Error creating project:', error);
    }
  };

  const deleteProject = async (projectId: string) => {
    try {
      const { error } = await supabase
        .from('projects')
        .delete()
        .eq('id', projectId);

      if (error) throw error;
      setProjects(projects.filter(p => p.id !== projectId));
      if (selectedProject?.id === projectId) {
        setSelectedProject(null);
        setOutputs([]);
      }
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-purple-600 dark:text-purple-400 text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-200">
      <header className="bg-white dark:bg-gray-800 border-b border-purple-100 dark:border-gray-700 sticky top-0 z-10 shadow-sm transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img
                src="/4594734b1_file_0000000040c471f8b341eb6a4b13f075.png"
                alt="MyNewFace AI"
                className="w-10 h-10 sm:w-12 sm:h-12 object-contain"
              />
              <h1 className="text-xl sm:text-2xl font-bold text-purple-900 dark:text-white">MyNewFace AI</h1>
            </div>
            <div className="flex items-center space-x-2">              <ThemeToggle />
              {!hasActivePlan && (
                <button
                  onClick={() => setShowSubscriptions(true)}
                  className="flex items-center space-x-2 px-3 sm:px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-lg transition duration-200 shadow-md hover:shadow-lg"
                >
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="hidden sm:inline">Upgrade</span>
                </button>
              )}
              <div className="flex items-center space-x-2 px-3 py-2 bg-purple-50 dark:bg-gray-700 border-2 border-purple-200 dark:border-gray-600 rounded-lg transition-colors duration-200">
                <CreditCard className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600 dark:text-purple-400" />
                <span className="font-bold text-purple-900 dark:text-white">{credits?.credits_remaining || 0}</span>
              </div>
              <ProfileMenu
                onLogout={handleLogout}
                onUpgrade={() => setShowSubscriptions(true)}
              />
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-purple-100 dark:border-gray-700 p-4 sm:p-6 transition-colors duration-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg sm:text-xl font-semibold text-purple-900 dark:text-white">Projects</h2>
                <button
                  onClick={() => setShowNewProject(true)}
                  className="p-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition duration-200"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              {showNewProject && (
                <form onSubmit={createProject} className="mb-4 space-y-3 p-4 bg-purple-50 dark:bg-gray-700 rounded-lg transition-colors duration-200">
                  <input
                    type="text"
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="Project name"
                    required
                    className="w-full px-3 py-2 border border-purple-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white transition-colors duration-200"
                  />
                  <textarea
                    value={newProjectDescription}
                    onChange={(e) => setNewProjectDescription(e.target.value)}
                    placeholder="Description (optional)"
                    className="w-full px-3 py-2 border border-purple-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none resize-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white transition-colors duration-200"
                    rows={2}
                  />
                  <div className="flex space-x-2">
                    <button
                      type="submit"
                      className="flex-1 px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition duration-200 text-sm"
                    >
                      Create
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowNewProject(false);
                        setNewProjectName('');
                        setNewProjectDescription('');
                      }}
                      className="flex-1 px-3 py-2 bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500 text-gray-700 dark:text-white rounded-lg transition duration-200 text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                {projects.length === 0 ? (
                  <p className="text-gray-500 dark:text-gray-400 text-center py-8 text-sm">No projects yet. Create your first project!</p>
                ) : (
                  projects.map((project) => (
                    <div
                      key={project.id}
                      className={`p-3 sm:p-4 rounded-lg border-2 transition cursor-pointer ${
                        selectedProject?.id === project.id
                          ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/30'
                          : 'border-purple-100 dark:border-gray-600 hover:border-purple-300 dark:hover:border-purple-500 bg-white dark:bg-gray-700'
                      }`}
                      onClick={() => setSelectedProject(project)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-1">
                            <Folder className="w-4 h-4 text-purple-600 dark:text-purple-400 flex-shrink-0" />
                            <h3 className="font-semibold text-purple-900 dark:text-white truncate text-sm sm:text-base">
                              {project.name}
                            </h3>
                          </div>
                          {project.description && (
                            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 line-clamp-2 mb-2">
                              {project.description}
                            </p>
                          )}
                          <div className="flex items-center space-x-1 text-xs text-gray-500 dark:text-gray-400">
                            <Clock className="w-3 h-3" />
                            <span>{formatDate(project.updated_at)}</span>
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteProject(project.id);
                          }}
                          className="ml-2 p-1.5 text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 rounded transition flex-shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-purple-100 dark:border-gray-700 p-4 sm:p-6 transition-colors duration-200">
              {selectedProject ? (
                <div>
                  <h2 className="text-xl sm:text-2xl font-semibold text-purple-900 dark:text-white mb-2">
                    {selectedProject.name}
                  </h2>
                  {selectedProject.description && (
                    <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm sm:text-base">{selectedProject.description}</p>
                  )}

                  <div className="mb-6">
                    <button
                      onClick={() => setShowFaceSwap(!showFaceSwap)}
                      className="flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition duration-200"
                    >
                      <Sparkles className="w-5 h-5" />
                      <span>{showFaceSwap ? 'Hide Face Swap' : 'New Face Swap'}</span>
                    </button>
                  </div>

                  {showFaceSwap && (
                    <div className="mb-6 p-4 sm:p-6 bg-purple-50 dark:bg-gray-700 rounded-xl border border-purple-200 dark:border-gray-600 transition-colors duration-200">
                      <FaceSwap
                        projectId={selectedProject.id}
                        onComplete={() => {
                          setShowFaceSwap(false);
                          fetchOutputs(selectedProject.id);
                        }}
                      />
                    </div>
                  )}

                  <div className="border-t border-purple-100 dark:border-gray-700 pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-purple-900 dark:text-white">Outputs</h3>
                      <button
                        onClick={() => selectedProject && fetchOutputs(selectedProject.id)}
                        className="text-sm text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition"
                      >
                        Refresh
                      </button>
                    </div>
                    {outputs.length === 0 ? (
                      <p className="text-gray-500 dark:text-gray-400 text-center py-12 text-sm">
                        No outputs yet. Generate your first output!
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 gap-4">
                        {outputs.map((output) => (
                          <div
                            key={output.id}
                            className="p-4 border border-purple-100 dark:border-gray-600 rounded-lg hover:border-purple-300 dark:hover:border-purple-500 transition bg-white dark:bg-gray-700"
                          >
                            <div className="flex items-center justify-between mb-3">
                              <span className="text-sm font-medium text-purple-700 dark:text-purple-400 capitalize flex items-center space-x-1">
                                {output.output_type === 'face_swap' && <Sparkles className="w-4 h-4" />}
                                <span>{output.output_type.replace('_', ' ')}</span>
                              </span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {formatDate(output.created_at)}
                              </span>
                            </div>
                            {output.output_type === 'face_swap' && output.output_data.output ? (
                              <div className="space-y-3">
                                <div className="relative aspect-video bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                                  <video
                                    src={output.output_data.output}
                                    controls
                                    className="w-full h-full object-contain"
                                  />
                                </div>
                                <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-300">
                                  <div>
                                    <p><strong>Status:</strong> {output.output_data.status}</p>
                                    <p><strong>Resolution:</strong> {output.output_data.resolution || '720p'}</p>
                                  </div>
                                  <a
                                    href={output.output_data.output}
                                    download
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center space-x-1 px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition duration-200"
                                  >
                                    <Download className="w-4 h-4" />
                                    <span>Download</span>
                                  </a>
                                </div>
                              </div>
                            ) : output.output_data.status === 'failed' || output.output_data.status === 'FAILED' ? (
                              <div className="text-sm text-red-600 dark:text-red-400 flex items-center space-x-2">
                                <span>Processing failed</span>
                                {output.output_data.error && <span className="text-xs">({output.output_data.error})</span>}
                              </div>
                            ) : (
                              <div className="text-sm text-gray-600 dark:text-gray-300 flex flex-col space-y-2">
                                <div className="flex items-center space-x-2">
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                  <span>Processing... Status: {output.output_data.status}</span>
                                </div>
                                <div className="text-xs text-gray-500 dark:text-gray-400">
                                  This may take 2-5 minutes. Page updates automatically every 5 seconds.
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-16 sm:py-24">
                  <Folder className="w-16 h-16 sm:w-20 sm:h-20 text-purple-300 dark:text-purple-600 mx-auto mb-4" />
                  <h3 className="text-lg sm:text-xl font-semibold text-gray-700 dark:text-gray-300 mb-2">No project selected</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm sm:text-base">Select a project from the list to view its outputs</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showSubscriptions && (
        <SubscriptionPlans
          onClose={() => setShowSubscriptions(false)}
          onPurchase={() => {
            fetchCredits();
            setShowSubscriptions(false);
          }}
        />
      )}
    </div>
  );
}
