import { useState, useEffect } from 'react';
import { Upload, Image as ImageIcon, Video, X, Loader2, Sparkles, CreditCard } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { UserCredits } from '../types/database';

interface FaceSwapProps {
  projectId: string;
  onComplete: () => void;
}

export default function FaceSwap({ projectId, onComplete }: FaceSwapProps) {
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [sourceImagePreview, setSourceImagePreview] = useState<string | null>(null);
  const [targetVideo, setTargetVideo] = useState<File | null>(null);
  const [targetVideoPreview, setTargetVideoPreview] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [credits, setCredits] = useState<UserCredits | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [estimatedTime, setEstimatedTime] = useState<number | null>(null);
  const [statusMessage, setStatusMessage] = useState('');

  useEffect(() => {
    fetchCredits();
  }, []);

  const fetchCredits = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_credits')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;
      setCredits(data);
    } catch (err) {
      console.error('Error fetching credits:', err);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSourceImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setSourceImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setError(null);
    } else {
      setError('Please select a valid image file');
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setTargetVideo(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setTargetVideoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setError(null);
    } else {
      setError('Please select a valid video file');
    }
  };

  const clearImage = () => {
    setSourceImage(null);
    setSourceImagePreview(null);
  };

  const clearVideo = () => {
    setTargetVideo(null);
    setTargetVideoPreview(null);
  };

  const sanitizeFileName = (fileName: string): string => {
    const extension = fileName.substring(fileName.lastIndexOf('.'));
    const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.'));

    const sanitized = nameWithoutExt
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .replace(/_{2,}/g, '_')
      .substring(0, 100);

    return `${sanitized}${extension}`.toLowerCase();
  };

  const uploadToStorage = async (file: File, path: string): Promise<string> => {
    const sanitizedName = sanitizeFileName(file.name);
    const fileName = `${Date.now()}_${sanitizedName}`;
    const filePath = `${path}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('uploads')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    const { data: { publicUrl } } = supabase.storage
      .from('uploads')
      .getPublicUrl(filePath);

    return publicUrl;
  };

  const handleProcess = async () => {
    if (!sourceImage || !targetVideo) {
      setError('Please upload both a photo and a video');
      return;
    }

    if (!credits || credits.credits_remaining < 1) {
      setError('Insufficient credits. Please purchase more credits to continue.');
      return;
    }

    setProcessing(true);
    setUploading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('User not authenticated');

      setStatusMessage('Uploading files...');
      setProgress(10);
      const imageUrl = await uploadToStorage(sourceImage, 'images');
      setProgress(20);
      const videoUrl = await uploadToStorage(targetVideo, 'videos');
      setProgress(30);
      setUploading(false);

      setStatusMessage('Starting face swap process...');
      setEstimatedTime(120);

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/face-swap`;
      console.log('Calling face-swap API:', apiUrl);
      console.log('Request body:', { projectId, imageUrl, videoUrl, resolution: '720' });

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          projectId,
          imageUrl,
          videoUrl,
          resolution: '720',
        }),
      });

      console.log('Response status:', response.status);
      const responseText = await response.text();
      console.log('Response body:', responseText);

      let result;
      try {
        result = JSON.parse(responseText);
      } catch (e) {
        throw new Error(`Invalid JSON response: ${responseText}`);
      }

      if (!response.ok) {
        throw new Error(result.error || `API error: ${response.status} - ${responseText}`);
      }

      setProgress(100);
      setStatusMessage('✅ Queued successfully! Your video will be ready in 2-5 minutes.');

      setCredits(prev => prev ? { ...prev, credits_remaining: result.credits_remaining } : null);

      setTimeout(() => {
        setSourceImage(null);
        setSourceImagePreview(null);
        setTargetVideo(null);
        setTargetVideoPreview(null);
        onComplete();
      }, 2000);
    } catch (err: any) {
      console.error('Face swap error:', err);
      setError(err.message || 'Failed to process face swap. Check console for details.');
    } finally {
      setProcessing(false);
      setUploading(false);
      setProgress(0);
      setEstimatedTime(null);
      setStatusMessage('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-6 h-6 text-purple-600 dark:text-purple-400" />
          <h3 className="text-xl font-semibold text-purple-900 dark:text-white">Face Swap</h3>
        </div>
        {credits && (
          <div className="flex items-center space-x-2 px-3 py-1.5 bg-purple-100 dark:bg-gray-700 rounded-lg transition-colors duration-200">
            <CreditCard className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span className="text-sm font-semibold text-purple-900 dark:text-white">
              {credits.credits_remaining} credits
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Source Photo (Face to use)
          </label>
          {!sourceImagePreview ? (
            <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-purple-300 dark:border-gray-600 border-dashed rounded-lg cursor-pointer bg-purple-50 dark:bg-gray-700 hover:bg-purple-100 dark:hover:bg-gray-600 transition">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <ImageIcon className="w-12 h-12 text-purple-400 dark:text-purple-500 mb-3" />
                <p className="mb-2 text-sm text-purple-600 dark:text-purple-400 font-medium">
                  Click to upload photo
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG or JPEG</p>
              </div>
              <input
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleImageUpload}
              />
            </label>
          ) : (
            <div className="relative w-full h-64 rounded-lg overflow-hidden border-2 border-purple-300 dark:border-gray-600">
              <img
                src={sourceImagePreview}
                alt="Source"
                className="w-full h-full object-cover"
              />
              <button
                onClick={clearImage}
                className="absolute top-2 right-2 p-1.5 bg-red-500 hover:bg-red-600 text-white rounded-full transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Target Video (Person speaking)
          </label>
          {!targetVideoPreview ? (
            <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-purple-300 dark:border-gray-600 border-dashed rounded-lg cursor-pointer bg-purple-50 dark:bg-gray-700 hover:bg-purple-100 dark:hover:bg-gray-600 transition">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Video className="w-12 h-12 text-purple-400 dark:text-purple-500 mb-3" />
                <p className="mb-2 text-sm text-purple-600 dark:text-purple-400 font-medium">
                  Click to upload video
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">MP4, MOV, AVI or WebM</p>
              </div>
              <input
                type="file"
                className="hidden"
                accept="video/*"
                onChange={handleVideoUpload}
              />
            </label>
          ) : (
            <div className="relative w-full h-64 rounded-lg overflow-hidden border-2 border-purple-300 dark:border-gray-600">
              <video
                src={targetVideoPreview}
                className="w-full h-full object-cover"
                controls
              />
              <button
                onClick={clearVideo}
                className="absolute top-2 right-2 p-1.5 bg-red-500 hover:bg-red-600 text-white rounded-full transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      {processing && (
        <div className="space-y-3 p-4 bg-purple-50 dark:bg-gray-700 rounded-lg border border-purple-200 dark:border-gray-600">
          <div className="flex items-center justify-between text-sm">
            <span className="text-purple-900 dark:text-white font-medium">{statusMessage}</span>
            {estimatedTime && (
              <span className="text-purple-600 dark:text-purple-400">
                Est. {Math.ceil(estimatedTime / 60)} min remaining
              </span>
            )}
          </div>
          <div className="w-full bg-purple-200 dark:bg-gray-600 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-purple-600 dark:bg-purple-500 h-2.5 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-xs text-purple-700 dark:text-purple-300">
            Please keep this page open. Processing may take 2-5 minutes depending on video length.
          </p>
        </div>
      )}

      <div className="flex justify-end">
        <button
          onClick={handleProcess}
          disabled={!sourceImage || !targetVideo || processing}
          className="flex items-center space-x-2 px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {processing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>{statusMessage || 'Processing...'}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>Generate Face Swap (1 credit)</span>
            </>
          )}
        </button>
      </div>

      <div className="mt-4 p-4 bg-purple-50 dark:bg-gray-700 border border-purple-200 dark:border-gray-600 rounded-lg transition-colors duration-200">
        <p className="text-sm text-purple-900 dark:text-gray-200">
          <strong>How it works:</strong> Upload a photo with the face you want to use, and a video of
          someone speaking. The AI will replace the speaker's face with the face from your photo while
          keeping the original movements and expressions.
        </p>
      </div>
    </div>
  );
}
