import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { CreditCard, Check, Loader2, X } from 'lucide-react';
import type { SubscriptionPlan, UserCredits } from '../types/database';

interface SubscriptionPlansProps {
  onClose: () => void;
  onPurchase: () => void;
}

export default function SubscriptionPlans({ onClose, onPurchase }: SubscriptionPlansProps) {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [credits, setCredits] = useState<UserCredits | null>(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [plansResult, creditsResult] = await Promise.all([
        supabase.from('subscription_plans').select('*').eq('active', true).order('price', { ascending: true }),
        supabase.from('user_credits').select('*').eq('user_id', user.id).maybeSingle(),
      ]);

      if (plansResult.data) setPlans(plansResult.data);
      if (creditsResult.data) setCredits(creditsResult.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (plan: SubscriptionPlan) => {
    setPurchasing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const newCredits = (credits?.credits_remaining || 0) + plan.credits;

      await supabase
        .from('user_credits')
        .update({ credits_remaining: newCredits })
        .eq('user_id', user.id);

      await supabase
        .from('credit_transactions')
        .insert([{
          user_id: user.id,
          credits_change: plan.credits,
          transaction_type: 'purchase',
          success: true,
        }]);

      onPurchase();
      onClose();
    } catch (error) {
      console.error('Error purchasing plan:', error);
      alert('Failed to purchase plan. Please try again.');
    } finally {
      setPurchasing(false);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-8 max-w-4xl w-full">
          <div className="text-center">
            <Loader2 className="w-8 h-8 text-purple-600 animate-spin mx-auto" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 sm:p-8 max-w-5xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-200">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-purple-900 dark:text-white">Choose Your Plan</h2>
            <p className="text-gray-600 dark:text-gray-300 mt-1">Select a plan to get more credits</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition"
          >
            <X className="w-6 h-6 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {credits && (
          <div className="mb-6 p-4 bg-purple-50 dark:bg-gray-700 border border-purple-200 dark:border-gray-600 rounded-lg transition-colors duration-200">
            <p className="text-sm text-purple-900 dark:text-white">
              <strong>Current Balance:</strong> {credits.credits_remaining} credits
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className="border-2 border-purple-200 dark:border-gray-600 rounded-xl p-6 hover:border-purple-400 dark:hover:border-purple-500 transition hover:shadow-lg bg-white dark:bg-gray-700"
            >
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-purple-900 dark:text-white mb-2">{plan.name}</h3>
                <div className="flex items-baseline justify-center space-x-1 mb-2">
                  <span className="text-4xl font-bold text-purple-600 dark:text-purple-400">${plan.price}</span>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">One-time purchase</p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center space-x-2">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">{plan.credits} AI face swaps</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">720p resolution</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">No expiration</span>
                </div>
              </div>

              <button
                onClick={() => handlePurchase(plan)}
                disabled={purchasing}
                className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {purchasing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5" />
                    <span>Purchase</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-lg transition-colors duration-200">
          <p className="text-sm text-blue-900 dark:text-blue-300">
            <strong>New users get 3 free credits!</strong> If a face swap fails to process, your credit will be automatically refunded.
          </p>
        </div>
      </div>
    </div>
  );
}
