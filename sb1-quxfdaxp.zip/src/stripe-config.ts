export interface StripeProduct {
  id: string;
  priceId: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  mode: 'payment' | 'subscription';
}

export const stripeProducts: StripeProduct[] = [
  {
    id: 'prod_TM0Z6vS7qkE6CC',
    priceId: 'price_1SPIXxEb1qyBPGaNBHA8QBdj',
    name: 'BASIC',
    description: '15 credits per month',
    price: 9.99,
    currency: 'usd',
    mode: 'subscription'
  },
  {
    id: 'prod_TM0akT4qfb57PF',
    priceId: 'price_1SPIYwEb1qyBPGaN03ecgznE',
    name: 'ADVANCED',
    description: '30 credits per month',
    price: 14.99,
    currency: 'usd',
    mode: 'subscription'
  },
  {
    id: 'prod_TM0azpHjPav93o',
    priceId: 'price_1SPIZTEb1qyBPGaNtJo9Dqes',
    name: 'PRO',
    description: '80 credits per month',
    price: 29.99,
    currency: 'usd',
    mode: 'subscription'
  }
];

export function getProductByPriceId(priceId: string): StripeProduct | undefined {
  return stripeProducts.find(product => product.priceId === priceId);
}