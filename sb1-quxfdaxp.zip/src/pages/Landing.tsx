import { Link } from 'react-router-dom';
import { Sparkles, Zap, Shield, Clock, Check, Star, ArrowRight, Mail } from 'lucide-react';
import ThemeToggle from '../components/ThemeToggle';

export default function Landing() {
  const features = [
    {
      icon: Sparkles,
      title: 'AI-Powered Face Swapping',
      description: 'State-of-the-art AI technology for seamless and realistic face swaps in videos',
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Process your videos in minutes, not hours. Our optimized pipeline delivers results quickly',
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your data is encrypted and secure. We take privacy seriously and never share your content',
    },
    {
      icon: Clock,
      title: 'Easy to Use',
      description: 'Simple three-step process: upload source image, upload target video, and download result',
    },
  ];

  const plans = [
    {
      name: 'Starter',
      price: 9,
      credits: 10,
      features: ['10 AI face swaps', '720p resolution', 'No expiration', 'Email support'],
    },
    {
      name: 'Professional',
      price: 29,
      credits: 50,
      features: ['50 AI face swaps', '720p resolution', 'No expiration', 'Priority support'],
      popular: true,
    },
    {
      name: 'Enterprise',
      price: 79,
      credits: 150,
      features: ['150 AI face swaps', '720p resolution', 'No expiration', '24/7 support'],
    },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Content Creator',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'MyNewFace AI has transformed how I create content. The quality is outstanding and the speed is incredible!',
      rating: 5,
    },
    {
      name: 'Michael Chen',
      role: 'Video Editor',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'As a professional video editor, I need tools that deliver. This platform exceeds my expectations every time.',
      rating: 5,
    },
    {
      name: 'Emma Rodriguez',
      role: 'Social Media Manager',
      avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'The ease of use is amazing! I can create engaging content for my clients in just minutes. Highly recommend!',
      rating: 5,
    },
  ];

  const steps = [
    {
      number: '01',
      title: 'Upload Source Image',
      description: 'Choose a clear photo of the face you want to use',
    },
    {
      number: '02',
      title: 'Upload Target Video',
      description: 'Select the video where you want to swap the face',
    },
    {
      number: '03',
      title: 'Download Result',
      description: 'Get your high-quality face-swapped video in minutes',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-200">
      <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-b border-slate-200 dark:border-gray-700 sticky top-0 z-50 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img
                src="/4594734b1_file_0000000040c471f8b341eb6a4b13f075.png"
                alt="MyNewFace AI"
                className="w-10 h-10 sm:w-12 sm:h-12 object-contain"
              />
              <h1 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                MyNewFace AI
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Link
                to="/login"
                className="px-4 py-2 text-slate-700 dark:text-gray-300 hover:text-slate-900 dark:hover:text-white font-medium transition"
              >
                Login
              </Link>
              <Link
                to="/signup"
                className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-gray-900 hover:bg-slate-800 dark:hover:bg-gray-100 rounded-lg font-semibold transition shadow-sm"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden pt-16 pb-24 sm:pt-24 sm:pb-32">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-purple-50/50 dark:from-blue-950/20 dark:to-purple-950/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-100 dark:bg-blue-900/50 text-blue-900 dark:text-blue-300 rounded-full text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4" />
            <span>Next Generation AI Face Swapping</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-slate-900 dark:text-white mb-6 leading-tight">
            Transform Your Videos with
            <br />
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              AI-Powered Face Swapping
            </span>
          </h2>
          <p className="text-xl text-slate-600 dark:text-gray-300 mb-10 max-w-3xl mx-auto">
            Create stunning, realistic face swaps in minutes. Perfect for content creators, marketers, and video professionals.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link
              to="/signup"
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-8 py-4 bg-slate-900 dark:bg-white text-white dark:text-gray-900 hover:bg-slate-800 dark:hover:bg-gray-100 rounded-lg font-semibold transition shadow-lg hover:shadow-xl"
            >
              <span>Start Free Trial</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="#how-it-works"
              className="w-full sm:w-auto px-8 py-4 border-2 border-slate-300 dark:border-gray-600 text-slate-900 dark:text-white hover:border-slate-400 dark:hover:border-gray-500 rounded-lg font-semibold transition"
            >
              Learn More
            </a>
          </div>
          <div className="mt-12 flex items-center justify-center space-x-8 text-sm text-slate-600 dark:text-gray-400">
            <div className="flex items-center space-x-2">
              <Check className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span>3 Free Credits</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span>No Credit Card Required</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span>Cancel Anytime</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white dark:bg-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mb-4">
              Why Choose MyNewFace AI?
            </h3>
            <p className="text-lg text-slate-600 dark:text-gray-300 max-w-2xl mx-auto">
              Cutting-edge technology meets simplicity. Create professional-quality face swaps effortlessly.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-6 bg-slate-50 dark:bg-gray-700 rounded-xl hover:shadow-lg transition border border-slate-200 dark:border-gray-600"
              >
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/50 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h4 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                  {feature.title}
                </h4>
                <p className="text-slate-600 dark:text-gray-300">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="how-it-works" className="py-16 sm:py-24 bg-gradient-to-br from-slate-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mb-4">
              How It Works
            </h3>
            <p className="text-lg text-slate-600 dark:text-gray-300 max-w-2xl mx-auto">
              Three simple steps to create amazing face-swapped videos
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 text-white text-2xl font-bold rounded-full mb-6">
                    {step.number}
                  </div>
                  <h4 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
                    {step.title}
                  </h4>
                  <p className="text-slate-600 dark:text-gray-300">
                    {step.description}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-blue-600 to-purple-600"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white dark:bg-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mb-4">
              Simple, Transparent Pricing
            </h3>
            <p className="text-lg text-slate-600 dark:text-gray-300 max-w-2xl mx-auto">
              Choose the plan that fits your needs. All plans include the same great features.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`relative p-8 rounded-2xl transition hover:shadow-xl ${
                  plan.popular
                    ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white scale-105'
                    : 'bg-slate-50 dark:bg-gray-700 border border-slate-200 dark:border-gray-600'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-yellow-400 text-slate-900 text-sm font-bold rounded-full">
                    Most Popular
                  </div>
                )}
                <div className="text-center mb-6">
                  <h4 className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                    {plan.name}
                  </h4>
                  <div className="flex items-baseline justify-center space-x-1 mb-2">
                    <span className={`text-5xl font-bold ${plan.popular ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                      ${plan.price}
                    </span>
                  </div>
                  <p className={plan.popular ? 'text-blue-100' : 'text-slate-600 dark:text-gray-300'}>
                    One-time purchase
                  </p>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3">
                      <Check className={`w-5 h-5 flex-shrink-0 ${plan.popular ? 'text-blue-100' : 'text-green-600 dark:text-green-400'}`} />
                      <span className={plan.popular ? 'text-blue-50' : 'text-slate-700 dark:text-gray-300'}>
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/signup"
                  className={`block w-full py-3 text-center font-semibold rounded-lg transition ${
                    plan.popular
                      ? 'bg-white text-blue-600 hover:bg-blue-50'
                      : 'bg-slate-900 dark:bg-white text-white dark:text-gray-900 hover:bg-slate-800 dark:hover:bg-gray-100'
                  }`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-gradient-to-br from-slate-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mb-4">
              What Our Users Say
            </h3>
            <p className="text-lg text-slate-600 dark:text-gray-300 max-w-2xl mx-auto">
              Join thousands of satisfied creators who trust MyNewFace AI
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-slate-200 dark:border-gray-700 hover:shadow-lg transition"
              >
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-slate-700 dark:text-gray-300 mb-6 italic">
                  "{testimonial.content}"
                </p>
                <div className="flex items-center space-x-3">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h5 className="font-semibold text-slate-900 dark:text-white">{testimonial.name}</h5>
                    <p className="text-sm text-slate-600 dark:text-gray-400">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Videos?
          </h3>
          <p className="text-xl text-blue-100 mb-10">
            Start creating amazing face-swapped content today with 3 free credits. No credit card required.
          </p>
          <Link
            to="/signup"
            className="inline-flex items-center space-x-2 px-8 py-4 bg-white text-blue-600 hover:bg-blue-50 rounded-lg font-semibold transition shadow-lg hover:shadow-xl"
          >
            <span>Get Started Free</span>
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      <footer className="bg-slate-900 dark:bg-gray-950 text-white py-12 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img
                  src="/4594734b1_file_0000000040c471f8b341eb6a4b13f075.png"
                  alt="MyNewFace AI"
                  className="w-10 h-10 object-contain"
                />
                <h4 className="text-xl font-bold">MyNewFace AI</h4>
              </div>
              <p className="text-gray-400 text-sm">
                Transform your videos with AI-powered face swapping technology.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Product</h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition">Features</a></li>
                <li><a href="#" className="hover:text-white transition">Pricing</a></li>
                <li><a href="#how-it-works" className="hover:text-white transition">How It Works</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Company</h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition">About Us</a></li>
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
                <li><a href="#" className="hover:text-white transition">Careers</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="mailto:semih@altinai.cloud" className="hover:text-white transition flex items-center space-x-2">
                    <Mail className="w-4 h-4" />
                    <span>semih@altinai.cloud</span>
                  </a>
                </li>
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2025 MyNewFace AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
