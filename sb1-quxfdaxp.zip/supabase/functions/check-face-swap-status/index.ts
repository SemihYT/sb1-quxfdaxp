import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const REPLICATE_API_KEY = 'r8_8kpzxjBMWqKTsifdfLq8IO2Fv1BKm8J3eCBRv';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { outputId } = await req.json();

    const { data: output, error: fetchError } = await supabase
      .from('outputs')
      .select('*')
      .eq('id', outputId)
      .eq('user_id', user.id)
      .maybeSingle();

    if (fetchError) {
      throw new Error('Database error fetching output');
    }

    if (!output) {
      throw new Error('Output not found');
    }

    if (output.output_data.output) {
      return new Response(
        JSON.stringify({
          status: 'succeeded',
          output: output,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const predictionId = output.output_data.id;
    if (!predictionId) {
      throw new Error('No prediction ID in output');
    }

    const predictionUrl = `https://api.replicate.com/v1/predictions/${predictionId}`;
    const statusResponse = await fetch(predictionUrl, {
      headers: {
        'Authorization': `Token ${REPLICATE_API_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    if (!statusResponse.ok) {
      throw new Error('Failed to check status');
    }

    const predictionData = await statusResponse.json();
    console.log('Replicate status:', predictionData.status);

    if (predictionData.status === 'succeeded') {
      const { error: updateError } = await supabase
        .from('outputs')
        .update({
          output_data: {
            ...output.output_data,
            ...predictionData,
            status: 'succeeded',
          },
        })
        .eq('id', outputId);

      if (updateError) {
        console.error('Failed to update output:', updateError);
      }

      const { data: updatedOutput } = await supabase
        .from('outputs')
        .select('*')
        .eq('id', outputId)
        .maybeSingle();

      return new Response(
        JSON.stringify({
          status: 'succeeded',
          output: updatedOutput,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    } else if (predictionData.status === 'failed' || predictionData.status === 'canceled') {
      const { error: updateError } = await supabase
        .from('outputs')
        .update({
          output_data: {
            ...output.output_data,
            status: predictionData.status,
            error: predictionData.error,
          },
        })
        .eq('id', outputId);

      return new Response(
        JSON.stringify({
          status: predictionData.status,
          message: predictionData.error || 'Processing failed',
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    return new Response(
      JSON.stringify({
        status: predictionData.status,
        logs: predictionData.logs || '',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Status check error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});