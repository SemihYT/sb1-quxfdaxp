import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const REPLICATE_API_KEY = 'r8_8kpzxjBMWqKTsifdfLq8IO2Fv1BKm8J3eCBRv';
const REPLICATE_API_URL = 'https://api.replicate.com/v1/predictions';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface FaceSwapRequest {
  projectId: string;
  imageUrl: string;
  videoUrl: string;
  resolution?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { projectId, imageUrl, videoUrl, resolution = '720' }: FaceSwapRequest = await req.json();

    const { data: creditsData, error: creditsError } = await supabase
      .from('user_credits')
      .select('credits_remaining, total_credits_used')
      .eq('user_id', user.id)
      .maybeSingle();

    if (creditsError) {
      throw new Error('Failed to fetch user credits');
    }

    if (!creditsData) {
      throw new Error('User credits not initialized. Please contact support.');
    }

    if (creditsData.credits_remaining < 1) {
      return new Response(
        JSON.stringify({ error: 'Insufficient credits', credits_remaining: 0 }),
        {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const { error: deductError } = await supabase
      .from('user_credits')
      .update({
        credits_remaining: creditsData.credits_remaining - 1,
        total_credits_used: creditsData.total_credits_used + 1,
      })
      .eq('user_id', user.id);

    if (deductError) {
      throw new Error('Failed to deduct credits');
    }

    console.log('Starting Replicate request...');
    const replicateResponse = await fetch(REPLICATE_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Token ${REPLICATE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        version: 'b55667691c9d39b12fb9bf46d1dc20d7bf8a93c7bc0455449cbd4ef18c39eb0e',
        input: {
          video: videoUrl,
          character_image: imageUrl,
          frames_per_second: 24,
          resolution: resolution,
        },
      }),
    });

    if (!replicateResponse.ok) {
      const errorText = await replicateResponse.text();
      console.error('Replicate error:', errorText);

      await supabase
        .from('user_credits')
        .update({
          credits_remaining: creditsData.credits_remaining,
        })
        .eq('user_id', user.id);

      throw new Error(`Replicate API error: ${errorText}`);
    }

    const predictionResult = await replicateResponse.json();
    console.log('Replicate response:', JSON.stringify(predictionResult));

    const predictionId = predictionResult.id;
    if (!predictionId) {
      await supabase
        .from('user_credits')
        .update({ credits_remaining: creditsData.credits_remaining })
        .eq('user_id', user.id);
      throw new Error('No prediction ID from Replicate');
    }

    const { data: outputData, error: outputError } = await supabase
      .from('outputs')
      .insert([{
        project_id: projectId,
        user_id: user.id,
        output_data: {
          ...predictionResult,
          imageUrl,
          videoUrl,
          resolution,
          status: predictionResult.status || 'starting',
          processedAt: new Date().toISOString(),
        },
        output_type: 'face_swap',
      }])
      .select()
      .single();

    if (outputError) {
      console.error('Failed to save output:', outputError);
    }

    await supabase
      .from('credit_transactions')
      .insert([{
        user_id: user.id,
        credits_change: -1,
        transaction_type: 'usage',
        output_id: outputData?.id || null,
        success: true,
      }]);

    return new Response(
      JSON.stringify({
        success: true,
        output_id: outputData?.id,
        prediction_id: predictionId,
        credits_remaining: creditsData.credits_remaining - 1,
        message: 'Face swap queued successfully. Check back in 2-5 minutes.',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Face swap error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});