/*
  # MyNewFace AI Database Schema

  ## Overview
  Creates the database structure for MyNewFace AI application to store user projects and their generated outputs.

  ## New Tables
  
  ### `projects`
  - `id` (uuid, primary key) - Unique identifier for each project
  - `user_id` (uuid, foreign key) - References auth.users, owner of the project
  - `name` (text) - Project name
  - `description` (text, optional) - Project description
  - `created_at` (timestamptz) - Timestamp when project was created
  - `updated_at` (timestamptz) - Timestamp when project was last updated
  
  ### `outputs`
  - `id` (uuid, primary key) - Unique identifier for each output
  - `project_id` (uuid, foreign key) - References projects table
  - `user_id` (uuid, foreign key) - References auth.users
  - `output_data` (jsonb) - Stores the generated output data
  - `output_type` (text) - Type of output (e.g., 'image', 'text', 'video')
  - `created_at` (timestamptz) - Timestamp when output was created

  ## Security
  
  ### Row Level Security (RLS)
  - RLS enabled on both tables
  - Users can only view, create, update, and delete their own projects
  - Users can only view, create, and delete their own outputs
  - All policies require authentication
  
  ## Notes
  - Uses `auth.uid()` for user identification
  - Cascading delete: when a project is deleted, all its outputs are deleted
  - Indexes added for performance on user_id and project_id lookups
*/

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create outputs table
CREATE TABLE IF NOT EXISTS outputs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  output_data jsonb NOT NULL DEFAULT '{}',
  output_type text NOT NULL DEFAULT 'image',
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_outputs_project_id ON outputs(project_id);
CREATE INDEX IF NOT EXISTS idx_outputs_user_id ON outputs(user_id);

-- Enable Row Level Security
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE outputs ENABLE ROW LEVEL SECURITY;

-- Projects policies
CREATE POLICY "Users can view own projects"
  ON projects FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own projects"
  ON projects FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own projects"
  ON projects FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own projects"
  ON projects FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Outputs policies
CREATE POLICY "Users can view own outputs"
  ON outputs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own outputs"
  ON outputs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own outputs"
  ON outputs FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update updated_at on projects
DROP TRIGGER IF EXISTS update_projects_updated_at ON projects;
CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON projects
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();