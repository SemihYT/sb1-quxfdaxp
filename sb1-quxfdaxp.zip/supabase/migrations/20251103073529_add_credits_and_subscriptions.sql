/*
  # Credits and Subscription System

  ## Overview
  Adds a credits system to track user usage and subscription plans.

  ## New Tables
  
  ### `user_credits`
  - `id` (uuid, primary key) - Unique identifier
  - `user_id` (uuid, foreign key) - References auth.users
  - `credits_remaining` (integer) - Number of credits available
  - `total_credits_used` (integer) - Total credits consumed
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### `credit_transactions`
  - `id` (uuid, primary key) - Unique identifier
  - `user_id` (uuid, foreign key) - References auth.users
  - `credits_change` (integer) - Credits added (positive) or used (negative)
  - `transaction_type` (text) - Type: 'initial', 'usage', 'purchase', 'refund'
  - `output_id` (uuid, nullable) - References outputs table for usage transactions
  - `success` (boolean) - Whether the operation was successful
  - `created_at` (timestamptz) - Transaction timestamp

  ### `subscription_plans`
  - `id` (uuid, primary key) - Unique identifier
  - `name` (text) - Plan name
  - `credits` (integer) - Credits included
  - `price` (numeric) - Price in dollars
  - `active` (boolean) - Whether plan is available
  - `created_at` (timestamptz) - Creation timestamp

  ## Security
  
  - RLS enabled on all tables
  - Users can only view and update their own credits
  - Users can view their own transactions
  - Everyone can view active subscription plans
  
  ## Notes
  - New users automatically get 3 free credits
  - Failed operations refund credits automatically
  - Comprehensive audit trail for all credit changes
*/

-- Create user_credits table
CREATE TABLE IF NOT EXISTS user_credits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  credits_remaining integer NOT NULL DEFAULT 3,
  total_credits_used integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create credit_transactions table
CREATE TABLE IF NOT EXISTS credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  credits_change integer NOT NULL,
  transaction_type text NOT NULL CHECK (transaction_type IN ('initial', 'usage', 'purchase', 'refund')),
  output_id uuid REFERENCES outputs(id) ON DELETE SET NULL,
  success boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create subscription_plans table
CREATE TABLE IF NOT EXISTS subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  credits integer NOT NULL,
  price numeric(10, 2) NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_user_credits_user_id ON user_credits(user_id);
CREATE INDEX IF NOT EXISTS idx_credit_transactions_user_id ON credit_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_credit_transactions_output_id ON credit_transactions(output_id);

-- Enable RLS
ALTER TABLE user_credits ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;

-- Policies for user_credits
CREATE POLICY "Users can view own credits"
  ON user_credits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own credits"
  ON user_credits FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "System can insert user credits"
  ON user_credits FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies for credit_transactions
CREATE POLICY "Users can view own transactions"
  ON credit_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own transactions"
  ON credit_transactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies for subscription_plans
CREATE POLICY "Anyone can view active plans"
  ON subscription_plans FOR SELECT
  TO authenticated
  USING (active = true);

-- Function to initialize credits for new users
CREATE OR REPLACE FUNCTION initialize_user_credits()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_credits (user_id, credits_remaining, total_credits_used)
  VALUES (NEW.id, 3, 0);
  
  INSERT INTO credit_transactions (user_id, credits_change, transaction_type)
  VALUES (NEW.id, 3, 'initial');
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-create credits for new users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION initialize_user_credits();

-- Function to update updated_at on user_credits
CREATE OR REPLACE FUNCTION update_user_credits_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_user_credits_updated_at ON user_credits;
CREATE TRIGGER update_user_credits_updated_at
  BEFORE UPDATE ON user_credits
  FOR EACH ROW
  EXECUTE FUNCTION update_user_credits_timestamp();

-- Insert default subscription plans
INSERT INTO subscription_plans (name, credits, price, active) VALUES
  ('Basic', 10, 9.99, true),
  ('Pro', 30, 24.99, true),
  ('Premium', 100, 79.99, true)
ON CONFLICT DO NOTHING;